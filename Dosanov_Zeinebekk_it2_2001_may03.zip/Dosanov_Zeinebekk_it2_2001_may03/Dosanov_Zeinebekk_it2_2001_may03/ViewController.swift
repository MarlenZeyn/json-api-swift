//
//  ViewController.swift
//  Dosanov_Zeinebekk_it2_2001_may03
//
//  Created by Marlen Zeyn on 03.05.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

